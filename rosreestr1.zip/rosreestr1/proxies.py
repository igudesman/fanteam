
proxy_list = [
    {'PROXY_HOST': '194.67.215.206', 'PROXY_PORT': 9031, 'PROXY_USER': 'o7mXUk', 'PROXY_PASS': 'Zfg4g9'},
    {'PROXY_HOST': '194.67.214.135', 'PROXY_PORT': 9909, 'PROXY_USER': 'e9p9B7', 'PROXY_PASS': 'cNx02D'},
    {'PROXY_HOST': '194.67.215.170', 'PROXY_PORT': 9794, 'PROXY_USER': 'e9p9B7', 'PROXY_PASS': 'cNx02D'},
             ]

proxy_index = 0